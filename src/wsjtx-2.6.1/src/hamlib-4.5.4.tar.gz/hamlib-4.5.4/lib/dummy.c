/* Dummy function to make sure libmisc never become an empty library.
 * Solaris linker does not like such libs.
 */

void dummy(void)
{

}

